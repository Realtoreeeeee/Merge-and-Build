import java.util.Random;
import java.util.*;

class GameObject {
    String name;
    int durability;
    int speed;

    public GameObject(String name, int durability, int speed) {
        this.name = name;
        this.durability = durability;
        this.speed = speed;
    }

    public void displayStats() {
        System.out.println(name + " Stats: ");
        System.out.println("Durability: " + durability);
        System.out.println("Speed: " + speed);
    }

    // Merge function to increase durability and speed
    public GameObject merge(GameObject other) {
        if (!this.name.equals(other.name)) {
            System.out.println("Cannot merge different objects!");
            return null;
        }

        String newName = this.name + "+";
        int newDurability = this.durability + other.durability;
        int newSpeed = this.speed + other.speed;

        return new GameObject(newName, newDurability, newSpeed);
    }
}

public class MergingGame {
    private static List<GameObject> objects = new ArrayList<>();
    private static Random rand = new Random();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Initialize some basic objects
        objects.add(new GameObject("Car", 10, 20));
        objects.add(new GameObject("Car", 10, 20));
        objects.add(new GameObject("Bike", 5, 30));

        System.out.println("Welcome to the Merge monkers!");
        displayObjects();

        while (true) {
            System.out.println("\n1. Merge objects");
            System.out.println("2. Test object");
            System.out.println("3. Exit");

            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    mergeObjects(scanner);
                    break;
                case 2:
                    testObject(scanner);
                    break;
                case 3:
                    System.exit(0);
                default:
                    System.out.println("Invalid choice, try again.");
            }
        }
    }

    private static void displayObjects() {
        System.out.println("Available Objects:");
        for (int i = 0; i < objects.size(); i++) {
            System.out.print((i + 1) + ". ");
            objects.get(i).displayStats();
        }
    }

    private static void mergeObjects(Scanner scanner) {
        displayObjects();
        System.out.println("Enter the indices of two objects to merge (e.g., 1 2): ");
        int idx1 = scanner.nextInt() - 1;
        int idx2 = scanner.nextInt() - 1;

        if (idx1 == idx2 || idx1 < 0 || idx2 < 0 || idx1 >= objects.size() || idx2 >= objects.size()) {
            System.out.println("Invalid indices!");
            return;
        }

        GameObject obj1 = objects.get(idx1);
        GameObject obj2 = objects.get(idx2);
        GameObject merged = obj1.merge(obj2);

        if (merged != null) {
            objects.remove(Math.max(idx1, idx2)); // Remove the higher index first
            objects.remove(Math.min(idx1, idx2)); // Then the lower index
            objects.add(merged);                  // Add the merged object
            System.out.println("Objects merged!");
        }
    }

    private static void testObject(Scanner scanner) {
        displayObjects();
        System.out.println("Choose an object to test (enter index): ");
        int idx = scanner.nextInt() - 1;

        if (idx < 0 || idx >= objects.size()) {
            System.out.println("Invalid index!");
            return;
        }

        GameObject obj = objects.get(idx);
        System.out.println("Testing " + obj.name + "...");
        runTest(obj);
    }

    private static void runTest(GameObject obj) {
        // Simple test simulation using speed and durability
        System.out.println(obj.name + " is on the test track!");
        int distance = rand.nextInt(100); // Random track distance
        int damage = rand.nextInt(20);    // Random damage

        if (obj.durability > damage) {
            System.out.println(obj.name + " survived with " + (obj.durability - damage) + " durability left!");
        } else {
            System.out.println(obj.name + " broke down...");
        }

        System.out.println(obj.name + " finished the track in " + (100 / obj.speed) + " seconds.");
    }
}
